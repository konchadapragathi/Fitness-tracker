import React from "react";
import "./Meditation.css";

function Meditation() {
  return (
    <div className="phone">
      {/* Header */}
      <div className="header">
        <span>Back</span>
        <span>Step 2 of 3</span>
      </div>

      {/* Progress dots */}
      <div className="progress">
        <span></span>
        <span className="active"></span>
        <span></span>
      </div>

      {/* Sections */}
      <div className="section">
        <h3>Daily Meditation Duration</h3>
        <input type="range" min="5" max="60" defaultValue="15" />
        <div className="labels">
          <span>5 min</span>
          <span>60 min</span>
        </div>
      </div>

      <div className="section">
        <h3>Focus Level</h3>
        <input type="range" min="1" max="10" defaultValue="5" />
        <div className="labels">
          <span>Low</span>
          <span>High</span>
        </div>
      </div>

      {/* Button */}
      <button className="btn">Continue</button>
    </div>
  );
}

export default Meditation;
