import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchCaloriesBurned } from "../utils/api";
import "./Fatloss.css";


function FatLoss() {
  const [activity, setActivity] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSearch = async () => {
    try {
      setError("");
      const data = await fetchCaloriesBurned(activity);

      if (!data || data.length === 0) {
        setError("No calorie data found for this activity.");
        return;
      }

      // ✅ Save results to localStorage
      localStorage.setItem(
        "fatLossResults",
        JSON.stringify({ activity, data })
      );

      // ✅ Redirect to output page
      navigate("/fatloss-output");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="video-container2">
      <video autoPlay muted loop className="bg-video">
        <source src="/images/fitnesstrackfatloss.mp4" type="video/mp4" />
      </video>
      <div className="centered-text2 text-white">
        <h1>Fat Loss</h1>
        <p>You’re not just changing your body—you’re rewriting your story</p>
        <input
          type="text"
          placeholder="Enter activity (e.g. running)"
          className="form-control mt-3"
          value={activity}
          onChange={(e) => setActivity(e.target.value)}
        />
        <button onClick={handleSearch}>Calculate Calories</button>
        {error && <p className="text-danger">{error}</p>}
      </div>
    </div>
  );
}

export default FatLoss;
