import React, { useEffect, useState } from "react";
import "./Output.css";

function Output() {
  const [calorieData, setCalorieData] = useState(null);

  useEffect(() => {
    // ✅ Get data from localStorage
    const storedData = localStorage.getItem("calorieTrackingData");
    if (storedData) {
      setCalorieData(JSON.parse(storedData));
    }
  }, []);

  if (!calorieData) {
    return (
      <div className="output-page">
        <h2>No calorie data found</h2>
        <p>Please go back to the Fitness page and calculate your calories.</p>
      </div>
    );
  }

  return (
    <div className="output-page">
      <h1>📊 Your Calorie Results</h1>
      <div className="card">
        <p><strong>Weight:</strong> {calorieData.weight} kg</p>
        <p><strong>Height:</strong> {calorieData.height} cm</p>
        <p><strong>Age:</strong> {calorieData.age}</p>
        <p><strong>Sex:</strong> {calorieData.sex}</p>
        <p><strong>Activity Level:</strong> {calorieData.activityLevel}</p>
      </div>

      <div className="results">
        <p><strong>Maintenance Calories:</strong> {calorieData.maintenance} kcal/day</p>
        <p><strong>Weight Loss Calories:</strong> {calorieData.loss} kcal/day</p>
        <p><strong>Weight Gain Calories:</strong> {calorieData.gain} kcal/day</p>
      </div>
    </div>
  );
}

export default Output;
