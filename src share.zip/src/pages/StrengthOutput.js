import React, { useEffect, useState } from "react";
import "./StrengthOutput.css";

function StrengthOutput() {
  const [results, setResults] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem("strengthResults");
    if (stored) {
      setResults(JSON.parse(stored));
    }
  }, []);

  if (!results) {
    return (
      <div className="output-page">
        <h2>No results found</h2>
        <p>Please go back to Strength page and try again.</p>
      </div>
    );
  }

  return (
    <div className="output-page">
      <h1>💪 Exercises for {results.muscle}</h1>
      {results.data.map((ex, i) => (
        <div key={i} className="card">
          <h3>{ex.name}</h3>
          <p><strong>Type:</strong> {ex.type}</p>
          <p><strong>Difficulty:</strong> {ex.difficulty}</p>
          <p><strong>Instructions:</strong> {ex.instructions}</p>
        </div>
      ))}
    </div>
  );
}

export default StrengthOutput;
