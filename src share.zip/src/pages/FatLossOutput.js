import React, { useEffect, useState } from "react";
import "./FatLossOutput.css";

function FatLossOutput() {
  const [results, setResults] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem("fatLossResults");
    if (stored) {
      setResults(JSON.parse(stored));
    }
  }, []);

  if (!results) {
    return (
      <div className="output-page">
        <h2>No results found</h2>
        <p>Please go back to Fat Loss page and try again.</p>
      </div>
    );
  }

  return (
    <div className="output-page">
      <h1>🔥 Calories Burned for {results.activity}</h1>
      {results.data.map((entry, i) => (
        <div key={i} className="card">
          <h3>{entry.name}</h3>
          <p><strong>Duration:</strong> {entry.duration_minutes} min</p>
          <p><strong>Calories Burned:</strong> {entry.total_calories} kcal</p>
        </div>
      ))}
    </div>
  );
}

export default FatLossOutput;
