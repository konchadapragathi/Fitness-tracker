import React, { useState } from "react"; 


function Fitness() {
  const [weight, setWeight] = useState(""); 
  const [height, setHeight] = useState(""); 
  const [age, setAge] = useState(""); 
  const [sex, setSex] = useState("male"); 
  const [activityLevel, setActivityLevel] = useState("sedentary"); 
  const [results, setResults] = useState(null); 
  const [error, setError] = useState(""); 
  const handleSubmit = (e) => { e.preventDefault(); setError(""); setResults(null); 
    const w = parseFloat(weight); 
    const h = parseFloat(height); 
    const a = parseFloat(age); if (isNaN(w) || isNaN(h) || isNaN(a)) { 
      setError("Please enter valid numbers for weight, height, and age."); 
      return; }
       // ✅ Calculate BMR 
       const bmr = 
       sex === "male" 
       ? 10 * w + 6.25 * h - 5 * a + 5 
       : 10 * w + 6.25 * h - 5 * a - 161; 
       const multipliers = { 
        sedentary: 1.2, 
        lightlyActive: 1.375, 
        moderatelyActive: 1.55, 
        veryActive: 1.725, 
        extremelyActive: 1.9, 
      }; 
      const multiplier = multipliers[activityLevel]; 
      if (!multiplier) { 
        setError("Invalid activity level selected."); 
        return; } 
        const maintenanceCalories = bmr * multiplier; 
        const weightLossCalories = maintenanceCalories - 500; 
        const weightGainCalories = maintenanceCalories + 500; 
        const resultData = { maintenance: maintenanceCalories.toFixed(2), 
        loss: weightLossCalories.toFixed(2), 
        gain: weightGainCalories.toFixed(2), 
      }; 
      setResults(resultData); 
      // ✅ Save to localStorage (optional) 
      localStorage.setItem( 
        "calorieTrackingData", 
        JSON.stringify({ 
          weight: w, 
          height: h, 
          age: a, 
          sex, 
          activityLevel, 
          ...resultData,
         }) 
        ); 
      };
  return (
    <div className="image" style={{ backgroundImage: "url('/images/fitnesstrack.jpeg')", backgroundSize: "cover", backgroundPosition: "center", height: "100vh", width:"170vh" }} >
      <div className="fitness-page">
        <p className="display-4 fw-bold">FITNESS TRACKING</p>
        <form id="calorie-form" className="mt-3" onSubmit={handleSubmit} >
          <input type="number" placeholder="Weight (kg)" required className="form-control mb-2" value={weight} onChange={(e) => setWeight(e.target.value)} />
          <input type="number" placeholder="Height (cm)" required className="form-control mb-2" value={height} onChange={(e) => setHeight(e.target.value)}/>
          <input type="number" placeholder="Age" required className="form-control mb-2" value={age} onChange={(e) => setAge(e.target.value)} />
          <label>Sex</label>
        <select value={sex} onChange={(e) => setSex(e.target.value)}>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
          <label>Activity Level</label>
        <select value={activityLevel} onChange={(e) => setActivityLevel(e.target.value)}
        >
          <option value="sedentary">Sedentary</option>
          <option value="lightlyActive">Lightly Active</option>
          <option value="moderatelyActive">Moderately Active</option>
          <option value="veryActive">Very Active</option>
          <option value="extremelyActive">Extremely Active</option>
        </select>
          <button type="submit" className="btn btn-success">Calculate Calories</button>
        </form>
        {error && <p className="text-danger">{error}</p>}

      {results && (
        <div className="results">
          <h3>📊 Calorie Results</h3>
          <p><strong>Maintenance:</strong> {results.maintenance} kcal/day</p>
          <p><strong>Weight Loss:</strong> {results.loss} kcal/day</p>
          <p><strong>Weight Gain:</strong> {results.gain} kcal/day</p>
        </div>
      )}
      </div>
    </div>
  );
}

export default Fitness;
