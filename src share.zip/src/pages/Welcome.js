import React from "react";
import { useNavigate } from "react-router-dom";
import "./Welcome.css"; // move your CSS here

function Welcome() {
  const navigate = useNavigate();

  return (
    <div className="phone">
      {/* Center Content */}
      <div className="content">
        <div className="logo">
          <img src="/icons/gym.png" alt="Gym" /> {/* replace with your logo */}
        </div>

        <div className="title">FITNESS GYM</div>
        <div className="welcome">Welcome Back</div>
      </div>

      {/* Buttons */}
      <div className="buttons">
        <button className="btn btn-outline" onClick={() => navigate("/login")}>
          LOGIN IN
        </button>
        <button className="btn btn-fill" onClick={() => navigate("/signup")}>
  SIGN UP
</button>

      </div>
    </div>
  );
}

export default Welcome;
