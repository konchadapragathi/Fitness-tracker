import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchStrengthExercises } from "../utils/api";
import "./Strength.css";

function Strength() {
  const [muscle, setMuscle] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSearch = async () => {
    try {
      setError("");
      const data = await fetchStrengthExercises(muscle);

      if (!data || data.length === 0) {
        setError(`No exercises found for "${muscle}".`);
        return;
      }

      // ✅ Save results to localStorage
      localStorage.setItem(
        "strengthResults",
        JSON.stringify({ muscle, data })
      );

      // ✅ Redirect to output page
      navigate("/strength-output");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="video-container">
      <video autoPlay muted loop className="bg-video">
        <source src="/images/fitnesstrackstrength.mp4" type="video/mp4" />
      </video>
      <div className="centered-text text-center text-white">
        <h1>Strength Training</h1>
        <p>Push your limits. Track your progress. Own your journey.</p>
        <input
          type="text"
          placeholder="Enter muscle (e.g. chest)"
          className="form-control mt-3"
          value={muscle}
          onChange={(e) => setMuscle(e.target.value)}
        />
        <button onClick={handleSearch}>Get Exercises</button>
        {error && <p className="text-danger">{error}</p>}
      </div>
    </div>
  );
}

export default Strength;
