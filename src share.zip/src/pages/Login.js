import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css"; // we'll move your CSS here

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!email || !password) {
      alert("Please enter both email and password.");
      return;
    }

    // ✅ Save user data locally
    localStorage.setItem("userData", JSON.stringify({ email, password }));
    localStorage.setItem("loggedInUser", email);

    // ✅ Redirect to goals page (or dashboard)
    navigate("/goals");
  };

  return (
    <div className="phone">
      {/* Header */}
      <div className="header">
        Hello<br />
        Login In!
      </div>

      {/* Card */}
      <div className="card">
        <h2>Welcome Back</h2>

        <form onSubmit={handleSubmit}>
          <label>Gmail</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
          />

          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
          />

          <div className="forgot">Forgot password?</div>

          <button type="submit" className="btn">LOGIN IN</button>
        </form>

        <div className="signup-text">
  Don’t have an account?
  <span onClick={() => navigate("/signup")}> Sign up</span>
</div>

      </div>
    </div>
  );
}

export default Login;
