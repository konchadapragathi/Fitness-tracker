import React from "react";
import "./Goals.css";
import { useNavigate } from "react-router-dom";

function Goals() {
  const navigate = useNavigate();

  return (
    <div className="container">
      <div className="top-bar">
        <div className="back-arrow">&#8592;</div>
        <div className="skip" onClick={() => navigate("/strength")}>SKIP</div>
      </div>

      <h1>What brings you to FitHealth?</h1>
      <p>Select your goals</p>

      <div className="goals-grid">
        <div className="goal-card" onClick={() => navigate("/fatloss")}>
          <div class="icon">⚖️</div>
          <span>Lose Weight</span>
        </div>
        <div className="goal-card" onClick={() => navigate("/strength")}>
          <div class="icon">💪</div>
          <span>Gain Strength</span>
        </div>
        <div className="goal-card" onClick={() => navigate("/tracking")}>
          <div class="icon">🧘‍♂️</div>
          <span>BMI</span>
        </div>
        <div className="goal-card" onClick={() => navigate("/meditation")}>
          <div class="icon">🧘‍♀️</div>
          <span>Meditation</span>
        </div>
        <div className="goal-card" onClick={() => navigate("/sleep")}>
          <div class="icon">😴</div>
          <span>Sleep Well</span>
        </div>
        <div className="goal-card" onClick={() => navigate("/workout")}>
          <div class="icon">🏋️</div>
          <span>Workout split</span>
        </div>
      </div>

      <button className="proceed-btn" onClick={() => navigate("/strength")}>
        PROCEED
      </button>
    </div>
  );
}

export default Goals;
