import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Signup.css";

function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!email || !password || !confirmPassword) {
      alert("Please fill all fields.");
      return;
    }
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }

    // ✅ Save user data locally (basic demo)
    localStorage.setItem("userData", JSON.stringify({ email, password }));
    localStorage.setItem("loggedInUser", email);

    // ✅ Redirect to goals page after signup
    navigate("/goals");
  };

  return (
    <div className="phone">
      {/* Header */}
      <div className="header">
        Create<br />Account
      </div>

      {/* Card */}
      <div className="card">
        <h2>Sign Up</h2>

        <form onSubmit={handleSubmit}>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
          />

          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
          />

          <label>Confirm Password</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm your password"
          />

          <button type="submit" className="btn">SIGN UP</button>
        </form>

        <div className="signup-text">
          Already have an account?
          <span onClick={() => navigate("/login")}> Sign In</span>
        </div>
      </div>
    </div>
  );
}

export default Signup;
