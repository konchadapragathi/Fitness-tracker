import React, { useState } from "react"; 
import { workoutPlan } from "../utils/api";

function Workout() {
  const [muscle, setMuscle] = useState(""); 
  const [plan, setPlan] = useState([]); 
  const handleSearch = () => { 
  const exercises = workoutPlan[muscle.toLowerCase()]; 
  if (!exercises) { alert(`No workout plan found for "${muscle}"`); return; } setPlan(exercises); };
  return (
  
      <div className="workout-page"
          style={{ backgroundImage: "url('/images/fitnesstrackworkout.jpeg')", backgroundSize: "cover", backgroundPosition: "center", height: "90vh", width:"150vh" }} >
        <h1>Workout Plans</h1>
        <p>Train smart. Target your goals. Build your body.</p>
        <input
          type="text"
          placeholder="Enter muscle (e.g. biceps)"
          className="form-control mt-3"
          value={muscle} 
          onChange={(e) => setMuscle(e.target.value)}
        />
        <button onClick={handleSearch}>Get Plan</button>

      {plan.map((ex, i) => (
        <div key={i} className="card">
          <h3>{ex.name}</h3>
          <p>Sets: {ex.sets}</p>
          <p>Reps: {ex.reps}</p>
        </div>
      ))}
      </div>
  );
}

export default Workout;
