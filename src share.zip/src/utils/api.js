// src/utils/api.js
const API_KEY = "Uez4mfjEZ4cbE1WhzidmgQ==yxg4RAF2Yf9tJiMv";

export async function fetchStrengthExercises(muscle) {
  const res = await fetch(
    `https://api.api-ninjas.com/v1/exercises?muscle=${encodeURIComponent(muscle)}`,
    { headers: { "X-Api-Key": API_KEY } }
  );
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

export async function fetchCaloriesBurned(activity) {
  const res = await fetch(
    `https://api.api-ninjas.com/v1/caloriesburned?activity=${encodeURIComponent(activity)}`,
    { headers: { "X-Api-Key": API_KEY } }
  );
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// Local workout plan JSON
export const workoutPlan = {
  biceps: [
    { name: "Bicep Curl", sets: 3, reps: 12 },
    { name: "Hammer Curl", sets: 3, reps: 10 },
    { name: "Concentration Curl", sets: 3, reps: 12 },
    { name: "Preacher Curl", sets: 3, reps: 10 },
    { name: "Cable Curl", sets: 3, reps: 15 }
  ],
  chest: [
    { name: "Push-Up", sets: 3, reps: 15 },
    { name: "Bench Press", sets: 4, reps: 10 },
    { name: "Incline Dumbbell Press", sets: 3, reps: 12 },
    { name: "Chest Fly", sets: 3, reps: 12 },
    { name: "Cable Crossover", sets: 3, reps: 15 }
  ],
  // ... add other muscle groups
};
